<?php require_once SITE_ROOT.'/views/share/nav.php'; ?>
<div class="container">
  <div class="row">
    <div class="col-md-4">
      <div class="well">
         <form>
          <div class="input-group">
            <span class="input-group-addon"><i class="fa fa-search"></i></span>
            <select class="form-control" id="search" name="filter">
              <option>All</option>
              <?php foreach($data['categories'] as $c): ?>
                <option value="<?=$c->id?>"><?=ucwords($c->title)?></option>
              <?php endforeach; ?>
            </select>
            <div class="input-group-btn">
              <button class="btn btn-primary btn-raised btn-sm" type="submit" style="margin-top: 18px">Submit</button>
            </div>
          </div>
        </form>
      </div>
    </div>
    <div class="col-md-8">
      <div class="">
      <div class="row">
        <?php foreach($data['users'] as $key): ?>
        <div class="col-md-4 mb-1">
          <div class="card">
            <img class="card-img-top img-responsive fjimage" src="img/<?=$key->service_foto?>"  alt="Card image cap">
            <div class="card-body">
              <p class="card-text"><?=(strlen($key->description)>50) ? ucfirst(substr($key->description, 0, 50)).'...' : ucfirst($key->description).'.'?></p>
              <p class="card-text text-primary"><?=ucfirst('call: '.$key->mobile)?></p>
              <small>
                <address>location: <?=ucfirst($key->address).', '.ucfirst($key->city)?></address>
              </small>
            </div>
          </div>
        </div>
      <?php endforeach; ?>
      </div>

      <div class="clearfix"></div>
      </div>
    </div>
  </div>
</div>