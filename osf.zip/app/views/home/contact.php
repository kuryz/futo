<?php require_once SITE_ROOT.'/views/share/nav.php'; ?>

<div class="container">
	<div class="row">
		<div class="col-md-8 col-md-offset-2">
		<div class="well">
		<h1 class="text-center"><u>Contact Us</u></h1>
			<h3>Our office is located at 19 Samek Road, Opposite IMSU Front Gate, Owerri. Imo State</h3>
			<p>You can also contact us on any of our help desk: +2348030633316, +2347060981706, +2347035707836 or email us at ckresearchconsults@gmail.com. Thanks for choosing ckprojectsresearch</p>
		</div>
	</div>
	</div>
</div>
