<?php require_once SITE_ROOT.'/views/share/nav.php'; if (!$user->isLoggedIn()) die(print('<script>window.location.href="login";</script>')); 

if (Session::exists('home')) {
	echo '<div class="container col-md-6 col-md-offset-3"><div class="alert alert-info">'.Session::flash('home').'</div></div>';
}
if (Input::exists()) {
	if(Token::check(Input::get('token'))){

		$validate = new Validate();
		$validation = $validate->check($_POST, array(
			'address' => array(
				'required' => true
			),
			'city' => array(
				'required' => true
			),
			'mobile' => array(
				'required' => true,
				'min' => 11
			),
			'category' => array(
				'required' => true
			),
			'description' => array(
				'required' => true,
				'min' => 5,
				'max' => 150
			)
		));
		if (!$validation->passed()) {
			foreach ($validation->errors() as $error) {
				echo '<div class="container col-md-6 col-md-offset-3"><div class="alert alert-warning panel">'.$error."</div></div>";
			}
		}else{
			Business::create();
		}
	}
}
?>

<div class="container col-md-6 col-md-offset-3">
	<div class="well well bs-component">
		<form class="form-horizontal" method="post" enctype="multipart/form-data">
			<fieldset>
				<legend>Update Account</legend>
				<div class="form-group">
					<label for="address" class="col-lg-2 control-label">Address</label>
					<div class="col-lg-10">
						<input type="text" class="form-control" id="address" name="address">
					</div>
				</div>
				<div class="form-group">
					<label for="city" class="col-lg-2 control-label">City</label>
					<div class="col-lg-10">
						<input type="text" class="form-control" id="city" name="city">
					</div>
				</div>
				<div class="form-group">
					<label for="mobile" class="col-lg-2 control-label">Mobile</label>
					<div class="col-lg-10">
						<input type="text" class="form-control" id="mobile" name="mobile">
					</div>
				</div>
				<div class="form-group">
					<label for="password" class="col-lg-2 control-label">Category</label>
					<div class="col-lg-10">
						<select class="form-control" name="category">
							<?php foreach ($data['categories'] as $key): ?>
								<option value="<?=$key->id?>"><?=ucwords($key->title)?></option>
							<?php endforeach; ?>
						</select>
					</div>
				</div>
				<div class="form-group">
					<label for="description" class="col-lg-2 control-label">Description</label>
					<div class="col-lg-10">
						<textarea class="form-control" id="description" name="description" rows="3"></textarea>
					</div>
				</div>
				<div class="form-group">
					<label for="photo" class="col-lg-4 control-label lead" style="font-size: 14px;font-family: impact" role="button">Click To Choose A photo</label>
					<div class="col-lg-8">
						<input type="file" class="" id="photo" name="photo" required="">
					</div>
				</div>
				<input type="hidden" name="token" value="<?=Token::generate();?>">
				<div class="form-group">
					<div class="col-lg-10 col-lg-offset-2">
						<button type="submit" class="btn btn-raised btn-primary">Update</button>
					</div>
				</div>
			</fieldset>
		</form>
	</div>
</div>
