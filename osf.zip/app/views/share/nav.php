 <nav class="navbar navbar-primary panel">
  <div class="container-fluid">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href=""><span style="font-family: arial">Online Service Finder</a>
    </div>

    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav navbar-right">
        <!-- <li class="active"><a href="/">Home <span class="sr-only">(current)</span></a></li> -->
        <li class="dropdown">
          <?php $user = new User;?>
          <a href="Javascript:void(0)" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"><i class="fa fa-user"></i> 
            <?php if(!$user->isLoggedIn()): ?>User Management
            <?php else:?>
              <?=escape(ucwords($user->data()->name))?>
            <?php endif; ?></a>
          <ul class="dropdown-menu">
          <?php if(!$user->isLoggedIn()): ?>
            <li><a href="register">SignUp</a></li>
            <li><a href="login">SignIn</a></li>
          <?php elseif($user->isLoggedIn() && $user->hasPermission('administrator')): ?>
            <li><a href="admin">Panel</a></li>
            <li><a href="logout">Logout</a></li>
          <?php else: ?>
            <li><a href="dashboard">Dashboard</a></li>
            <li><a href="logout">Logout</a></li>
          <?php endif; ?>
          </ul>
            
        </li>
        <li><a href="./"> Home <span class="btn-danger badge focus"></span></a></li>
         <!-- <li><a href="">Hire a Writer</a></li> 
         <li><a href="">Projects</a></li> -->
         <li><a href="about/jerry/5">About</a></li>
         <li><a href="contact">Contact Us</a></li>
      </ul>
    </div><!-- /.navbar-collapse -->
  </div><!-- /.container-fluid -->
</nav>
<div class="mb"></div>