<?php require_once SITE_ROOT.'/views/share/nav.php'; ?>

<div class="container">
	<div class="row">
		<div class="col-sm-3 mb-1">
			<div class="well">
				<table class="table">
					<tr>
						<th>Alphabet</th>
						<th>Created</th>
					</tr>
				</table>
			</div>
		</div>
		
		<div class="clearfix"></div>		
	</div>
</div>
