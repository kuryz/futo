<?php require_once SITE_ROOT.'/views/share/nav.php'; if (!$user->isLoggedIn() || !$user->hasPermission('administrator')) die(print('<script>window.location.href="login";</script>')); ?>

<div class="container col-md-8 col-md-offset-2">
	<div class="well well bs-component">
		<table class="table table-responsive table-bordered">
			<th>Name</th>
			<th>Job Description</th>
			<tbody>
				<?php foreach ($data['services'] as $key ):?>
				<tr>
					<td><?=ucwords($key->name)?></td>
					<td><?=ucfirst($key->description)?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	</div>
</div>