<?php require_once SITE_ROOT.'/views/share/nav.php'; if (!$user->isLoggedIn() || !$user->hasPermission('administrator')) die(print('<script>window.location.href="login";</script>'));

if (Session::exists('success')) {
	echo '<div class="container col-md-6 col-md-offset-3"><div class="alert alert-success">'.Session::flash('success').'</div></div>';
}
if (Session::exists('error')) {
	echo '<div class="container col-md-6 col-md-offset-3"><div class="alert alert-warning">'.Session::flash('error').'</div></div>';
}
if (Input::exists()) {
	if(Token::check(Input::get('token'))){

	$validate = new Validate();
	$validation = $validate->check($_POST, array(
		'title' => array(
			'required' => true
		),
		'description' => array(
			'required' => true
		)
	));
	if (!$validation->passed()) {
		foreach ($validation->errors() as $error) {
			echo '<div class="container col-md-6 col-md-offset-3"><div class="alert alert-warning">'.$error."</div></div>";
		}
	}else{
		Admin::createCategory();
	}
}
}
?>

<div class="container col-md-6 col-md-offset-3">
	<div class="well well bs-component">
		<form class="form-horizontal" method="post">
			<fieldset>
				<legend>Create Category</legend>
				<div class="form-group">
					<label for="title" class="col-lg-2 control-label">Title</label>
					<div class="col-lg-10">
						<input type="text" class="form-control" id="title" name="title">
					</div>
				</div>
				<div class="form-group">
					<label for="description" class="col-lg-2 control-label">Description</label>
					<div class="col-lg-10">
						<textarea class="form-control" id="description" name="description" rows="3"></textarea>
					</div>
				</div>

				<input type="hidden" name="token" value="<?=Token::generate();?>">
				<div class="form-group">
					<div class="col-lg-10 col-lg-offset-2">
						<button type="submit" class="btn btn-raised btn-primary">Create</button>
					</div>
				</div>
			</fieldset>
		</form>
	</div>
</div>