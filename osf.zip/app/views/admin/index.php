<?php require_once SITE_ROOT.'/views/share/nav.php'; if (!$user->isLoggedIn() || !$user->hasPermission('administrator')) die(print('<script>window.location.href="login";</script>')); ?>

<div class="container">
	<div class="row">
		<div class="col-sm-3 mb-1">
			<a href="category">
				<div class="card mx-auto btn-danger" id="well">
				<i class="fa fa-pencil fa-2x"></i>
				Create Category
				</div>
			</a>
		</div>
		<div class="col-sm-3 mb-1">
			<a href="category-view">
				<div class="card mx-auto btn-primary" id="well">
				<i class="fa fa-eye fa-2x"></i>
				All Categories
				</div>
			</a>
		</div>
		<div class="col-sm-3 mb-1">
			<a href="online-services">
				<div class="card mx-auto btn-warning" id="well">
				<i class="fa fa-eye fa-2x"></i>
				Services
				</div>
			</a>
		</div>
		<div class="clearfix"></div>		
	</div>
</div>
