<?php 

 $route = new FjtRouter;
/*$route->go('/', function(){
	echo "Hello this is the work of the Holy Spirit";
});*/
$route->go('/', 'home@index');
$route->go('/login', 'auth@login');
$route->go('/register', 'auth@register');
$route->go('/postsignup', 'auth@postregister');
$route->go('/about/:id/:we', 'home@about');
$route->go('/contact', 'home@contact');
$route->go('/logout', 'auth@logout');
$route->go('/dashboard', 'business@index');
$route->go('/admin', 'admin@index');
$route->go('/category', 'admin@category');
$route->go('/category-view', 'admin@category_index');
$route->go('/online-services', 'admin@service');

// echo "<pre>";
// print_r($route);
$route->submit();