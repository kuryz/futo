<?php 


class User_model
{
	public $name,$age;
}