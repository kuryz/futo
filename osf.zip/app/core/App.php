<?php 

class App
{
	public $controller, $method,$params = [];
	private $_controller, $_method, $_params = [];

	public function done()
	{
		if(file_exists('../app/controllers/'.$this->controller.'.php')):
			$this->_controller = $this->controller;
			unset($this->controller);
		endif;
		require_once '../app/controllers/' .$this->_controller.'.php';
		$this->_controller = new $this->_controller;
		if(isset($this->method)):
			if(method_exists($this->_controller, $this->method)):
				$this->_method = $this->method;
				unset($this->method);
			else:
				die("<h1>404...</h1><br><a href='./'>Home</a>");
			endif;
		endif;
		$this->_params = $this->params ? array_values($this->params) : [];
		call_user_func_array([$this->_controller, $this->_method], $this->_params);
	}

}