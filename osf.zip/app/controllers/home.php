<?php 

class Home extends Controller 
{
	public function __construct()
	{
		$this->_db = DB::getInstance();
		$this->user = $this->model('User');
	}

	public function index()
	{
		$categories = $this->_db->get('categories')->results();
		$users = $this->_db->get('users', array('service_foto', '<>', 'null'))->results()	;
		$this->view('home/index', compact('users', 'categories'));
	}

	public function contact()
	{
		return $this->view('home/contact');
	}

	public function about($name='',$age)
	{
		$this->user->age = $age;
		$this->user->name  = $name;
		$this->view('home/about', compact('name','age'));
	}
}