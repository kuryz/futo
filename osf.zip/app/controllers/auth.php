<?php 


class Auth extends Controller 
{
	/*public function __construct()
	{
		$this->user = $this->model('User');//1Diy4cjCjujsELJwpVR6c7Et4o7SPkvk3C
	}*/

	public function register($name = '')
	{
		return $this->view('user/register');
	}

	public function postregister()
	{
		$user = new User();
		$salt = Hash::salt(32);
		try {
			$user->create(array(
				'email' => Input::get('email'),
				'password' => Hash::make(Input::get('password'), $salt),
				'salt' => $salt,
				'name' => Input::get('name'),
				'joined' => date('Y-m-d H:i:s'),
				'group' => 2,
			));

			Session::flash('home', 'You have been registered and can now log in!');
			Redirect::to('login');
		} catch (Exception $e) {
			die($e->getMessage());
		}
		//return $this->view('user/register');
	}

	public function login($name = '')
	{
		$user = new User();
		return $this->view('user/login');
	}

	public function postLogin()
	{
		$user = new User();
      	$remember = (Input::get('remember') === 'on') ? true : false;
      	$login = $user->login(Input::get('email'), Input::get('password'), $remember);
       	if ($login) {
        	Redirect::to('./');
		}else{
			echo "error";
		}
	}

	public function logout()
	{
		$user = new User();
		$user->logout();
		Redirect::to('login');
	}
}