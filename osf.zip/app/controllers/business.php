<?php 
class Business extends Controller
{
	
	function __construct()
	{
		$this->_db = DB::getInstance();
		$this->file = $this->model('File');
	}
	public function index()
	{
		$categories = $this->_db->get('categories')->results();
		return $this->view('business/index', compact('categories'));
	}

	public function create()
	{
		$user = new User();
		$file = Input::hasFile('photo');
		$custom_file_name = $this->file->move_to($file,'img/');
		//var_dump($file);
		$data = array(
			'city' => strtolower(Input::get('city')),
			'address' => strtolower(Input::get('address')),
			'mobile' => Input::get('mobile'),
			'category' => strtolower(Input::get('category')),
			'description' => strtolower(Input::get('description')),
			'service_foto' => $custom_file_name
		);
		try {
			$old_file = $user->data()->service_foto;
			if (!is_null($old_file)) {
				$this->file->delete('img/', $old_file);
			}
			$user->update($data, $user->data()->id);
			Session::flash('home', 'Ok! everything is fine');
			Redirect::to('dashboard');
		} catch (Exception $e) {
			//die($e->getMessage());
			Session::flash('home', $e->getMessage());
			Redirect::to('dashboard');
		}
	}
}