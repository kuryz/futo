<?php 
class Admin extends Controller
{
	function __construct()
	{
		$this->_db = DB::getInstance();
	}
	public function index()
	{
		return $this->view('admin/index');
	}

	public function create()
	{
		return $this->view('admin/project/create');
	}

	public function category_index()
	{
		$categories = $this->_db->get('categories')->results();
		//return $categories;
		return $this->view('admin/category/index', compact('categories'));
	}

	public function category()
	{
		return $this->view('admin/category/create');
	}

	public function createCategory()
	{
		$data = array(
			'title' => strtolower(Input::get('title')),
			'description' => strtolower(Input::get('description'))
		);
		if (!$this->_db->insert('categories', $data)) {
			Session::flash('error', 'Unsuccessful');
			Redirect::to('category');
		}else{
			Session::flash('success', 'Inserted');
			Redirect::to('category');
		}
	}

	public function service()
	{
		$services = $this->_db->get('users', array('id', '>', 1))->results();
		return $this->view('admin/service/index', compact('services'));
	}
}