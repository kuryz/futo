<!DOCTYPE html>
<html>
<base href="/osf/">
<title>Online Service Finder</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<!-- CSS  -->      
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link href="css/bootstrap-material-design.min.css" rel="stylesheet">
<link href="css/ripples.min.css" rel="stylesheet">
<link href="css/style.css" rel="stylesheet">  
<link rel="stylesheet" type="text/css" href="fonts/css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/slick.css">
<body>

<?php 
//define('base_path', $_SERVER['SERVER_NAME']. $_SERVER['REQUEST_URI']);
require_once '../app/init.php';
// echo base_path;
$app = new FjtRouter;

?>
</body>
<!-- jQuery Library -->
<script src="js/jquery-1.12.3.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/ripples.min.js"></script>
<script src="js/material.min.js"></script>
<script>
$(document).ready(function() {
// This command is used to initialize some elements and make them work properly
$.material.init();
});
</script>
<script src="js/slick.js"></script>
 </body>
 </html>
