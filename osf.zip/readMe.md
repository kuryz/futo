Alway remember to set htaccess RewriteBase /nameOfAppFolder/ and then the base tag in public/index href="/nameOfAppFolder/" and call FJTee's router class
#how to use paginator class
#controller
$all = $this->_db->paginate({table}, perpage)->results();
$users = $all['data'];
$total = $all['total'];
$per_page = $all['pages'];//to get perpage
return $this->view('admin/index', compact('users','total','per_page'));

#view                      	 
$p = new Pagination;
$total=$data['total'];
//start loop
foreach($data['users'] as $user => $key) 
	$delta_time = time() - strtotime($key->joined);
	$hours = floor($delta_time / 3600);
	$delta_time %= 3600;
	$min = floor($delta_time / 60);//echo "{$hours} hours ago and {$minutes} and minutes";?>
<tr>
    <td><?=ucwords($key->name)?></td>
</tr>
endforeach

$p->render($total,$data['per_page']);//for paging
