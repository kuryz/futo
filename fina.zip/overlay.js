function showOverlay() {
    // Adds the fullscreen overlay
    var oDiv = $("<div></div>");
    oDiv.attr("id", "lt_overlay");
    oDiv.css("display", "block");
    $("body").append(oDiv);

    // Adds the spinner
    var lDiv = $("<i></i>");
    lDiv.attr("id", "lt_loading");
    // lDiv.addClass("fa fa-cog fa-spin fa-5x");
    lDiv.css("display", "block");
    $("body").append(lDiv);
}

function hideOverlay() {
    $("#lt_loading").remove();
    $("#lt_overlay").remove();
}