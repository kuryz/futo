function navigate(){
    window.location.href = "login.php";
}